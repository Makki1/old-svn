#ifndef	DEFAULTS_H
#define	DEFAULTS_H

#define LED_yellow		A,6
#define LED_green		A,7

#define	P_MOSI			B,2
#define	P_MISO			B,3
#define	P_SCK			B,1
#define P_SS			B,0

#define	MCP2515_CS		B,4
#define	MCP2515_INT		E,7

//#define RXnBF_FUNKTION
//#define MCP2515_RX0BF 	C,6
//#define MCP2515_RX1BF 	C,5


//#define USE_SOFTWARE_SPI

#endif	// DEFAULTS_H	
