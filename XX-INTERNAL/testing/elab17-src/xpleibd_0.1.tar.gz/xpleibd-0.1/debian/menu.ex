?package(xpleibd):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="xpleibd" command="/usr/bin/xpleibd"
