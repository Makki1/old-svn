#!/usr/bin/perl
#
# Jason Sharpee <jason@sharpee.com>  GPL Licensed
# Based on code by: James Golovich <james@gnuinter.net>
# Based on code by: Patrick Lidstone <patrick@lidstone.net>

use IO::Socket::INET;  

use lib './lib', '../lib';
use Asterisk::Manager;

$|++;

my $astman = new Asterisk::Manager;

$astman->user('phpconfig');
$astman->secret('php[onfig');
$astman->host('127.0.0.1');

$astman->connect || die $astman->error . "\n";



#$astman->setcallback('MessageWaiting', \&MessageWaiting_callback);
$astman->setcallback('DEFAULT', \&default_callback);


print STDERR "Listing for Asterisk events...\n";
!system("echo Listing for Asterisk events... > /usr/src/xpl/test.log");

$astman->eventloop;

$astman->disconnect;


sub default_callback {
	print "*default_callback---------------------------\n";
	my (%stuff) = @_;
	foreach (keys %stuff) {
		print STDERR "$_: ". $stuff{$_} . "\n";
	}
	print STDERR "\n";
}

sub MessageWaiting_callback {
	print "###MessageWaiting_callback---------------------------\n";
	my (%stuff) = @_;
	foreach (keys %stuff) {
		print STDERR "$_: ". $stuff{$_} . "\n";
	}
	print STDERR "\n";
	!system("echo MessageWaiting_callback >> /usr/src/xpl/test.log");
}
