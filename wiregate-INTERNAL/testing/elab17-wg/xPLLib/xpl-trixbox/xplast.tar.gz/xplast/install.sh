#!/bin/sh
# RedHat installer for xpl Asterisk 

echo "Installing Asterisk xPL interface"
echo ""

if [ -d /usr/sbin/xpl ]
then
 echo "/usr/sbin/xpl already exists"

else
        mkdir /usr/sbin/xpl
fi

######################################################
echo "Installing Asterisk event app..."

cp getvm.cgi /var/www/cgi-bin
cp xplastevn /usr/sbin/xpl/xplastevn
cp xplsendvm.pl /usr/sbin/xpl/xplsendvm.pl
cp xplsendcall.pl /usr/sbin/xpl/xplsendcall.pl
cp xplastevn.start /etc/init.d/xplastevn
cp xplastevn.amp /usr/sbin/xplastevn

chmod 4755 /var/www/cgi-bin/getvm.cgi
chmod 755  /usr/sbin/xpl/xplastevn
chmod 755  /usr/sbin/xpl/xplsendvm.pl
chmod 755  /usr/sbin/xpl/xplsendcall.pl
chmod 755  /etc/init.d/xplastevn
chmod 755  /usr/sbin/xplastevn

chkconfig --add xplastevn

service xplastevn stop
echo "--------------------------------------------------"
echo "| if this is a new installation an error is OK!! |"
echo "--------------------------------------------------"
service xplastevn start
service xplastevn status

echo "Done."

######################################################
echo ""
echo "Installing Asterisk xPL heartbeat app..."

cp xplheartbeat /usr/sbin/xpl/xplheartbeat
cp xplheartbeat.start /etc/init.d/xplheartbeat
cp xplheartbeat.amp /usr/sbin/xplheartbeat

chmod 755 /usr/sbin/xplheartbeat
chmod 755 /usr/sbin/xpl/xplheartbeat
chmod 755 /etc/init.d/xplheartbeat

chkconfig --add xplheartbeat

service xplheartbeat stop
echo "--------------------------------------------------"
echo "| if this is a new installation an error is OK!! |"
echo "--------------------------------------------------"
service xplheartbeat start
service xplheartbeat status

echo "Done."

######################################################

echo ""
echo "Installing Asterisk xPL AGI app..."

cp xplring.agi /var/lib/asterisk/agi-bin/

chmod 755 /var/lib/asterisk/agi-bin/xplring.agi

echo "Done."

######################################################

echo ""
echo "xpl Asterisk installed."
