#!/usr/bin/perl -w
################################################################################
#
# xPL Monitor for Perl
#
# Version 1.0
#
# Copyright (C) 2003 John Bent
# http://www.xpl.myby.co.uk/
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
# 
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
# Linking this library statically or dynamically with other modules is
# making a combined work based on this library. Thus, the terms and
# conditions of the GNU General Public License cover the whole
# combination.
# As a special exception, the copyright holders of this library give you
# permission to link this library with independent modules to produce an
# executable, regardless of the license terms of these independent
# modules, and to copy and distribute the resulting executable under
# terms of your choice, provided that you also meet, for each linked
# independent module, the terms and conditions of the license of that
# module. An independent module is a module which is not derived from
# or based on this library. If you modify this library, you may extend
# this exception to your version of the library, but you are not
# obligated to do so. If you do not wish to do so, delete this
# exception statement from your version.
#
################################################################################
use strict;
use warnings;

use IO::Socket;
use IO::Select;
use Sys::Hostname;

my $xpl_port = 50000;
my $xpl_socket;
my $computername = hostname();
my $msg;
my $xpl_ip = inet_ntoa((gethostbyname($computername))[4]);
$computername = validInstance($computername);
my $xpl_instance = "ag-asterisk.$computername";


sub validInstance {
# This routine ensures an xPL instance is valid
# by removing any invalid characters and trimming to
# 16 characters.
	my $instance = $_[0];
	$instance =~ s/(-|\.|!|;)//g;
	if (length($instance) > 16) {
		$instance = substr($instance,0,16);
	}
	return $instance;
}

sub sendxplmsg {
# Generic routine for sending an xPL message.
  my $msg;
  $msg = "$_[0]\n{\nhop=1\nsource=$xpl_instance\ntarget=$_[1]\n}\n$_[2]\n{\n$_[3]\n}\n";
    my $ipaddr   = inet_aton('255.255.255.255');
    my $portaddr = sockaddr_in(3865, $ipaddr);
    my $sockUDP = IO::Socket::INET->new(PeerPort => 3865,
                                   Proto => 'udp'
      );
  
    $sockUDP->autoflush(1);
    $sockUDP->sockopt(SO_BROADCAST,1);
    $sockUDP->send($msg,0,$portaddr);
  
    close $sockUDP;
}

# Try and bind to a free port
while (!$xpl_socket && $xpl_port < 50200) {
  $xpl_socket = IO::Socket::INET->new(
    Proto     => 'udp',
    LocalPort => $xpl_port,
  );	
  if (!$xpl_socket) {
    $xpl_port = $xpl_port + 1;
  }
}
die "Could not create socket: $!\n" unless $xpl_socket;

sendxplmsg("xpl-stat","*","hbeat.app","interval=30\nport=$xpl_port\nremote-ip=$xpl_ip");

print "\nxPL Monitor ready.\n";
print "Listing on $xpl_ip...\n\n";

while (defined($xpl_socket)) {
  recv($xpl_socket,$msg,1500,0);
  print "$msg\n";
}

close($xpl_socket);

1;
