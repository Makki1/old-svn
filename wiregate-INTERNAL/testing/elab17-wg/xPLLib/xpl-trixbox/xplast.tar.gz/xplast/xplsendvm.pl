#!/usr/bin/perl
################################################################################
#
# xPL Asterisk Voicemail info sender
# Version 1.0
# 11/18/04
#
################################################################################

use IO::Socket;
use IO::Select;
use Sys::Hostname;

# Variables to hold components of xPL message
my ($msgtype, $msgsource, $msgtarget, $schemaclass, $schematype, $msgtxt);
my $loop=1;
my $computername = hostname();
$computername = validInstance($computername);

eval((`/sbin/ifconfig eth0`)[1] =~ /inet addr:(\S+)/);
my $xpl_ip = $1;

my $mbox=$ARGV[0];
my $context=$ARGV[1];
my $folder="INBOX";
my $BaseURL="http://$web_ip/cgi-bin/getvm.cgi?mailbox=$mbox&msgid=";

$newmessages = &msgcount($context, $mbox, "INBOX");

###############
# XPL setup
###############

$msgsource = "aah-asterisk.$computername";
$msgtarget = "*";
$schemaclass = "asterisk";
$schematype = "vminfo";
$msgtype = "trig";

###############

#print "xPL Send Voicemail info\n\n";

$msgtxt = "\x0Ambox=$mbox\x0A";
$msgtxt = $msgtxt ."MsgCount=$newmessages\x0A";
$msgtxt = $msgtxt ."MsgURL=$BaseURL\x0A";


foreach $msg (&messages($context, $mbox, $folder)) {

        $fields = &getfields($context, $mbox, $folder, $msg);
        my ($l_name) = $fields->{'callerid'}=~ /^\"(.*)\".*/;
        my ($l_number) = $fields->{'callerid'}=~ /<(.*)>$/;
        $duration = $fields->{'duration'};
        if ($duration) {
                $duration = $duration;
        } else {
                $duration = "Unknown";
        }

        $msgtxt = $msgtxt . "MsgNum$loop=$msg\x0A";
        $msgtxt = $msgtxt . "Phone$loop=$l_number\x0A";
        $msgtxt = $msgtxt . "CLN$loop=$l_name\x0A";
        $msgtxt = $msgtxt . "Dur$loop=$duration\x0A";
        $msgtxt = $msgtxt . "Date$loop=$fields->{'origdate'}\x0A";
        $msgtxt = $msgtxt . "Chanel$loop=$fields->{'callerchan'}\x0A";
$loop++;
}

my $MSG = "xpl-$msgtype\x0A{\x0Ahop=1\x0Asource=$msgsource\x0Atarget=$msgtarget\x0A}\x0A$schemaclass\.$schematype\x0A{$msgtxt}\x0A";
    my $ipaddr   = inet_aton('255.255.255.255');
    my $portaddr = sockaddr_in(3865, $ipaddr);
    my $sockUDP = IO::Socket::INET->new(PeerPort => 3865,
      Proto => 'udp'
      );
  
    $sockUDP->autoflush(1);
    $sockUDP->sockopt(SO_BROADCAST,1);
    $sockUDP->send($MSG,0,$portaddr);  
    close $sockUDP;

#    print "The message was sent successfully.\n";

1;


sub msgcount()
{
        my ($context, $mailbox, $folder) = @_;
        my $path = "/var/spool/asterisk/voicemail/$context/$mailbox/$folder";
        if (opendir(DIR, $path)) {
                my @msgs = grep(/^msg....\.txt$/, readdir(DIR));
                closedir(DIR);
                return sprintf "%d", $#msgs + 1;
        }
        return "0";
}

sub msgcountstr()
{
        my ($context, $mailbox, $folder) = @_;
        my $count = &msgcount($context, $mailbox, $folder);
        if ($count > 1) {
                "$count messages";
        } elsif ($count > 0) {
                "$count message";
        } else {
                "no messages";
        }
}

sub messages()
{
        my ($context, $mailbox, $folder) = @_;
        my $path = "/var/spool/asterisk/voicemail/$context/$mailbox/$folder";
        if (opendir(DIR, $path)) {
                my @msgs = sort grep(/^msg....\.txt$/, readdir(DIR));
                closedir(DIR);
                return map { s/^msg(....)\.txt$/$1/; $_ } @msgs;
        }
        return ();
}

sub getfields()
{
        my ($context, $mailbox, $folder, $msg) = @_;
        my $fields;

        if (open(MSG, 

"</var/spool/asterisk/voicemail/$context/$mailbox/$folder/msg${msg}.txt")) {
                while(<MSG>) {
                        s/\#.*$//g;
                        if (/^(\w+)\s*\=\s*(.*)$/) {
                                $fields->{$1} = $2;
                        }
                }
                close(MSG);
                $fields->{'msgid'} = $msg;
        } else { print "Unable to open '$msg' in '$mailbox', '$folder'\n"; }
        $fields;
}

sub validInstance {
# This routine ensures an xPL instance is valid
# by removing any invalid characters and trimming to
# 16 characters.
	my $instance = $_[0];
	$instance =~ s/(-|\.|!|;)//g;
	if (length($instance) > 16) {
		$instance = substr($instance,0,16);
	}
	return $instance;
}


